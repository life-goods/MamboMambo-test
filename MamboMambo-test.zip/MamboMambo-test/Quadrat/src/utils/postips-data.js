export const postipsData = [
    {
        number: '01',
        title: 'Analyser et explorer',
        content: 'Nous considérons qu’il est essentiel de placer le dirigeant en position de réflexion sur ses modes d’action',
        subContent: 'Analyser la trajectoire ainsi que les influences personnelles et contextuelles qui agissent sur les modes de gestion et la conduite du dirigeant.',
        link: 'https://google.com'
    },
    {
        number: '02',
        title: 'Observer et révéler',
        content: 'Nous considérons qu’il est essentiel de placer le dirigeant en position de réflexion sur ses modes d’action',
        subContent: 'Analyser la trajectoire ainsi que les influences personnelles et contextuelles qui agissent sur les modes de gestion et la conduite du dirigeant.',
        link: 'https://google.com'
    },
    {
        number: '03.',
        title: 'Définir l’idéal managérial',
        content: 'Nous considérons qu’il est essentiel de placer le dirigeant en position de réflexion sur ses modes d’action',
        subContent: 'Analyser la trajectoire ainsi que les influences personnelles et contextuelles qui agissent sur les modes de gestion et la conduite du dirigeant.',
        link: 'https://google.com'
    },
    {
        number: '04',
        title: 'Réinventer les pratiques',
        content: 'Nous considérons qu’il est essentiel de placer le dirigeant en position de réflexion sur ses modes d’action',
        subContent: 'Analyser la trajectoire ainsi que les influences personnelles et contextuelles qui agissent sur les modes de gestion et la conduite du dirigeant.',
        link: 'https://google.com'
    },
    {
        number: '05',
        title: 'Appliquer dans l’action',
        content: 'Nous considérons qu’il est essentiel de placer le dirigeant en position de réflexion sur ses modes d’action',
        subContent: 'Analyser la trajectoire ainsi que les influences personnelles et contextuelles qui agissent sur les modes de gestion et la conduite du dirigeant.',
        link: 'https://google.com'
    }
]